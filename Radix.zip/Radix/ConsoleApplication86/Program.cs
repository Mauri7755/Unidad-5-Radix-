﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication86
{
    class Program
    {
        static void Main(string[] args)
        {
            Radix n = new Radix();
            
            n.Cargar();
            n.Metodo();
            n.Imprimir();
            Console.WriteLine("");
            Console.WriteLine("");

            Radix2 m = new Radix2();
           
            Console.WriteLine("");
            Console.WriteLine("");
            m.Cargar();
            m.Metodo();
            m.Imprimir();
            Console.WriteLine("");
            Console.WriteLine("");
           
            Radix3 z = new Radix3();

            z.Cargar();
            z.Metodo();
            z.Imprimir();
            Console.WriteLine("");
            Console.WriteLine("");

            Radix4 q = new Radix4();

            q.Cargar();
            q.Metodo();
            q.Imprimir();
            Console.WriteLine("");
            Console.WriteLine("");

            Radix5 n5 = new Radix5();

            n5.Cargar();
            n5.Metodo();
            n5.Imprimir();
        }
    }
}
