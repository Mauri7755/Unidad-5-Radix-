﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication86
{
    class Radix4
    {
        private int[] vector;//se creo el vector

        public void Cargar()
        {
            Console.WriteLine(" 55,42,0,-3,0,-1,2,4,7");
            Console.WriteLine("");

            Console.Write("Cuantos longitud del vector: ");//se le pide al usuario de cuanto es su vector
            string linea;//se delcara variable
            linea = Console.ReadLine();//se declara variable para poder hacer los numeros que se pide en el vector
            int cant;
            cant = int.Parse(linea);
            vector = new int[cant];
            for (int f = 0; f < vector.Length; f++)
            {
                Console.Write("Ingrese elemento " + (f + 1) + ": ");//se realiza el vector 
                linea = Console.ReadLine();//numero para el vector
                vector[f] = int.Parse(linea);//vector
            }
        }

        public void Metodo()
        {
            int t;
            for (int a = 1; a < vector.Length; a++)//me todo de burbuja
                for (int b = vector.Length - 1; b >= a; b--)//se hace la compracion de los numeros para saber cual es el menor y el mayor para ponerlos en ascendete
                {
                    if (vector[b - 1] > vector[b])
                    {
                        t = vector[b - 1];
                        vector[b - 1] = vector[b];
                        vector[b] = t;
                    }
                }
        }

        public void Imprimir()
        {
            Console.WriteLine("Vector ordenados en forma ascendente");
            for (int f = 0; f < vector.Length; f++)
            {
                Console.Write(vector[f] + "  ");//se imprime los numeros 
            }
            Console.ReadKey();
        }
    }
}